import os
import sys
import pandas as pd
import requests
import time
from concurrent.futures import ThreadPoolExecutor
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

sys.stdout = open(sys.stdout.fileno(), mode='w', encoding='latin-1', buffering=1, errors='ignore')

input_excel_file = r'Excel 2\GRI_2017_2020 (1).xlsx'
output_folder = r'C:\Users\KOM\Documents\Excel 2\Excel Outputs'

error_log_dir = r'C:\Users\KOM\Documents\Excel 2\Excel Outputs\DL_Error_Logs'
os.makedirs(error_log_dir, exist_ok=True)

error_log_df = pd.DataFrame(columns=['BRnum', 'Error Type'])
successful_downloads_df = pd.DataFrame(columns=['BRnum', 'Download Status'])
failed_downloads_df = pd.DataFrame(columns=['BRnum', 'Error Type'])

def download_file(row):
    br_number = row['BRnum']
    download_status = 'Not Downloaded'
    
    pdf_url = row['Pdf_URL']
    if not pd.isna(pdf_url) and pd.notna(pdf_url) and isinstance(pdf_url, str) and pdf_url.startswith(('http://', 'https://')):
        pdf_path = os.path.join(output_folder, f'{br_number}.pdf')
        try:
            response = requests.get(pdf_url, timeout=10, stream=True)
            if response.status_code == 200:
                with open(pdf_path, 'wb') as pdf_file:
                    for chunk in response.iter_content(chunk_size=1024):
                        pdf_file.write(chunk)
                print(f"Downloaded PDF for BR number {br_number}")
                download_status = 'Downloaded'
                successful_downloads_df.loc[len(successful_downloads_df)] = [br_number, download_status]
            else:
                print(f"Failed to download PDF for BR number {br_number}: HTTP status code {response.status_code}")
                error_log_df.loc[len(error_log_df)] = [br_number, f'HTTP Error {response.status_code}']
        except requests.exceptions.Timeout:
            print(f"Timeout while downloading PDF for BR number {br_number}. Trying HTML download.")
            error_log_df.loc[len(error_log_df)] = [br_number, 'Timeout']
        except requests.exceptions.RequestException as e:
            print(f"Failed to download PDF for BR number {br_number}: {str(e)}")
            error_log_df.loc[len(error_log_df)] = [br_number, str(e)]
        except UnicodeDecodeError as ue:
            print(f"Unicode Decode Error while processing PDF for BR number {br_number}: {str(ue)}")
            error_log_df.loc[len(error_log_df)] = [br_number, 'Unicode Decode Error']
    
    backup_url = row.get('Report Html Address')
    if backup_url and not pd.isna(backup_url) and isinstance(backup_url, str) and backup_url.startswith(('http://', 'https://')):
        try:
            response = requests.get(backup_url, timeout=10, stream=True)
            if response.status_code == 200:
                html_path = os.path.join(output_folder, f'{br_number}.html')
                with open(html_path, 'wb') as html_file:
                    for chunk in response.iter_content(chunk_size=1024):
                        html_file.write(chunk)
                print(f"Downloaded HTML for BR number {br_number}")
                download_status = 'HTML Downloaded'
                successful_downloads_df.loc[len(successful_downloads_df)] = [br_number, download_status]
            else:
                print(f"Failed to download HTML for BR number {br_number}: HTTP status code {response.status_code}")
                error_log_df.loc[len(error_log_df)] = [br_number, f'HTTP Error {response.status_code}']
        except requests.exceptions.Timeout:
            print(f"Timeout while downloading HTML for BR number {br_number}. Skipping.")
            error_log_df.loc[len(error_log_df)] = [br_number, 'Timeout']
        except requests.exceptions.RequestException as e:
            print(f"Failed to download HTML for BR number {br_number}: {str(e)}")
            error_log_df.loc[len(error_log_df)] = [br_number, str(e)]
        except UnicodeDecodeError as ue:
            print(f"Unicode Decode Error while processing HTML for BR number {br_number}: {str(ue)}")
            error_log_df.loc[len(error_log_df)] = [br_number, 'Unicode Decode Error']
    
    return download_status

def parallel_download(df, max_workers=50):
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        results = list(executor.map(download_file, df.to_dict('records')))
    return results

def start_download():
    start_time = time.time()
    df = pd.read_excel(input_excel_file)

    download_statuses = parallel_download(df, max_workers=50)

    df['Download Status'] = download_statuses
    df.to_excel(input_excel_file, index=False)

    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"Download and update completed in {elapsed_time:.2f} seconds.")

    error_log_file = os.path.join(error_log_dir, 'error_log.csv')
    error_log_df.to_csv(error_log_file, index=False, encoding='latin-1')

    successful_downloads_file = 'successful_downloads.csv'
    failed_downloads_file = 'failed_downloads.csv'
    
    successful_downloads_df.to_csv(successful_downloads_file, index=False, encoding='latin-1')
    failed_downloads_df.to_csv(failed_downloads_file, index=False, encoding='latin-1')
    
    messagebox.showinfo("Download Complete", "Download and update completed.")

# Create a simple UI
root = tk.Tk()
root.title("File Download Manager")

frame = ttk.Frame(root)
frame.pack(padx=20, pady=20)

start_button = ttk.Button(frame, text="Start Download", command=start_download)
start_button.pack(pady=10)

progress_label = ttk.Label(frame, text="Downloading...")
progress_label.pack()

progress_bar = ttk.Progressbar(frame, length=300, mode='indeterminate')
progress_bar.pack(pady=10)

root.mainloop()
